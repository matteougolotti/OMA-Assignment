package com.TabuSearch;

public enum MovesType {
	SWAP
}

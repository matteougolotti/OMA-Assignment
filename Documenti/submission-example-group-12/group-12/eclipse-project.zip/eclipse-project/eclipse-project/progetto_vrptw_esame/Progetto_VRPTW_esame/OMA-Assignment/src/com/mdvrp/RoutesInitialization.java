package com.mdvrp;

public enum RoutesInitialization {
	RANDOM,
	NEAREST_NEIGHBOR
}
